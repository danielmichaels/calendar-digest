# Writing a notifier

A notifier is a name and one method:

```ts
import type { Notification, Notifier } from '@danielmichaels/worker-kit/notify';

export function myNotifier(options: MyOptions): Notifier {
	return {
		name: 'my-channel',
		async send(notification: Notification): Promise<void> {
			// deliver it, or throw
		},
	};
}
```

Everything below is a complete implementation you can paste into your own repo.
None of it belongs in the kit: `resolveNotifiers` is site-supplied precisely so a
new channel never needs a kit release.

## The contract

`send` receives:

```ts
interface Notification {
	id: string;
	kind: string;
	summary: string;
	fields: Record<string, string>;
	source: { table: string; id: string };
	meta?: { status: 'failed' | 'unroutable'; attempts: number; lastError: string | null };
}
```

Four rules, all of which the kit relies on:

1. **Throw to retry.** Resolving means delivered — the kit records that channel and
   acks the message once every channel has resolved. Throwing records `last_error`
   and retries only the channels that have not delivered. A notifier that swallows a
   failure loses the enquiry silently.
2. **Check the response.** `fetch` does not throw on a 4xx or 5xx. If you do not
   check `response.ok`, every failed webhook looks like a success.
3. **Name yourself.** `name` is the idempotency key the kit stores per delivery. It
   must be stable across deploys and unique within the array `resolveNotifiers`
   returns; two channels sharing a name are treated as one.
4. **Handle `meta`.** When present, the delivery has exhausted its retries and this
   is the last chance anyone hears about it. Say so in the message — a fallback that
   looks identical to a normal notification hides an outage.

`resolveNotifiers` returns an array. Every notifier in it is attempted at the same
time and independently: a Telegram outage neither blocks the email nor causes a
duplicate Slack post when the message is retried. Only the channels that have not
delivered are attempted again.

## Telegram

A bot token from `@BotFather` and the numeric chat id of the person or group. To
find a chat id, message the bot and read
`https://api.telegram.org/bot<token>/getUpdates`.

Store both as secrets: `wrangler secret put TELEGRAM_BOT_TOKEN`.

```ts
import type { Notification, Notifier } from '@danielmichaels/worker-kit/notify';

export interface TelegramNotifierOptions {
	token: string;
	chatId: string;
}

function escapeHtml(value: string): string {
	return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function formatTelegram({ summary, fields, meta }: Notification): string {
	const lines = [`<b>${escapeHtml(summary)}</b>`, ''];

	for (const [name, value] of Object.entries(fields)) {
		lines.push(`<b>${escapeHtml(name)}:</b> ${escapeHtml(value)}`);
	}

	if (meta) {
		lines.push('', `<i>Fallback after ${meta.attempts} sweeps (${meta.status}).</i>`);
	}

	return lines.join('\n');
}

export function telegramNotifier({ token, chatId }: TelegramNotifierOptions): Notifier {
	return {
		name: 'telegram',
		async send(notification: Notification): Promise<void> {
			const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					chat_id: chatId,
					text: formatTelegram(notification),
					parse_mode: 'HTML',
					disable_web_page_preview: true,
				}),
			});

			if (!response.ok) {
				throw new Error(`telegram sendMessage responded ${response.status}`);
			}
		},
	};
}
```

`parse_mode: 'HTML'` rather than MarkdownV2, which requires escaping eighteen
characters and will eventually be handed a message body that breaks it. Escape the
three HTML entities and you are done.

Telegram caps a message at 4096 characters. A long free-text field will be rejected
with a 400, which this notifier turns into a retry that can never succeed — truncate
in `summarize` if your form allows long input.

## SMS

Cloudflare has no SMS product, so this is an external API. Twilio shown; MessageBird
and Vonage differ only in the request shape.

Twilio uses HTTP Basic auth with the Account SID as the username. Store the auth
token as a secret.

```ts
import type { Notification, Notifier } from '@danielmichaels/worker-kit/notify';

export interface SmsNotifierOptions {
	accountSid: string;
	authToken: string;
	from: string;
	to: string;
	maxLength?: number;
}

export function smsNotifier({
	accountSid,
	authToken,
	from,
	to,
	maxLength = 320,
}: SmsNotifierOptions): Notifier {
	return {
		name: 'sms',
		async send({ summary, fields, meta }: Notification): Promise<void> {
			const prefix = meta ? `[${meta.status}] ` : '';
			const body = `${prefix}${summary}${fields.email ? ` — ${fields.email}` : ''}`.slice(
				0,
				maxLength,
			);

			const response = await fetch(
				`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
				{
					method: 'POST',
					headers: {
						Authorization: `Basic ${btoa(`${accountSid}:${authToken}`)}`,
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: new URLSearchParams({ From: from, To: to, Body: body }),
				},
			);

			if (!response.ok) {
				throw new Error(`twilio responded ${response.status}`);
			}
		},
	};
}
```

SMS is the one channel where you should not send `fields` wholesale. Every segment
costs money and a 5000-character message field becomes dozens of them, so this sends
the summary and one identifying field, hard-truncated. Treat SMS as a pager that
tells you to go and look, not as the notification itself.

Pair it with a real channel:

```ts
resolveNotifiers: (_kind, env) => [
	slackNotifier({ url: env.SLACK_WEBHOOK_URL }),
	smsNotifier({ /* … */ }),
],
```

## Email, via Cloudflare Email Sending

Cloudflare Email Service sends transactional mail straight from a Worker through a
binding — no API key, no third-party account.

Onboard the sending domain once:

```sh
npx wrangler email sending enable yourdomain.com
npx wrangler email sending list
```

Then add the binding to **both** the top-level and `env.staging` blocks:

```jsonc
{
	"send_email": [
		{
			"name": "NOTIFY_EMAIL",
			"destination_address": "ops@yourdomain.com"
		}
	]
}
```

`destination_address` pins the binding to one recipient, which is exactly what a
notifier wants — the Worker cannot be talked into mailing anyone else. Use
`allowed_destination_addresses` for a small allow list, or omit both to send to any
verified destination in the account. `allowed_sender_addresses` restricts the `from`.

Run `wrangler types` after adding the binding and use the generated `Env` rather
than hand-writing the interface.

```ts
import type { Notification, Notifier } from '@danielmichaels/worker-kit/notify';

export interface EmailNotifierOptions {
	binding: SendEmail;
	from: string;
	to: string;
}

function escapeHtml(value: string): string {
	return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function bodies({ summary, fields, meta }: Notification): { text: string; html: string } {
	const rows = Object.entries(fields);
	const footer = meta
		? `Delivered through the fallback after ${meta.attempts} sweeps (${meta.status}).${
				meta.lastError ? ` Last error: ${meta.lastError}` : ''
			}`
		: '';

	const text = [
		summary,
		'',
		...rows.map(([name, value]) => `${name}: ${value}`),
		...(footer ? ['', footer] : []),
	].join('\n');

	const html = [
		`<h2>${escapeHtml(summary)}</h2>`,
		'<dl>',
		...rows.flatMap(([name, value]) => [
			`<dt><strong>${escapeHtml(name)}</strong></dt>`,
			`<dd>${escapeHtml(value).replace(/\n/g, '<br>')}</dd>`,
		]),
		'</dl>',
		...(footer ? [`<p><em>${escapeHtml(footer)}</em></p>`] : []),
	].join('');

	return { text, html };
}

export function emailNotifier({ binding, from, to }: EmailNotifierOptions): Notifier {
	return {
		name: 'email',
		async send(notification: Notification): Promise<void> {
			const { text, html } = bodies(notification);
			const subject = notification.meta
				? `[${notification.meta.status}] ${notification.summary}`
				: notification.summary;

			await binding.send({ to, from, subject, text, html });
		},
	};
}
```

Wire it with the binding from `env`, since a notifier factory takes values rather
than reading the environment itself:

```ts
resolveNotifiers: (_kind, env) => [
	emailNotifier({
		binding: env.NOTIFY_EMAIL,
		from: 'forms@yourdomain.com',
		to: 'ops@yourdomain.com',
	}),
],
```

Five things that bite:

- **Pass `to` even though `destination_address` makes it redundant.** The binding
  defaults the recipient to `destination_address` when `to` is omitted, but the
  `EmailMessageBuilder` type requires at least one of `to`, `cc` or `bcc`, so
  omitting it is valid at runtime and a type error at build time. Pass it and let
  `destination_address` stay as the guard rail that stops the Worker mailing anyone
  else.
- **The `from` domain must be onboarded.** Sending from a domain that is not enabled
  throws `E_SENDER_NOT_VERIFIED`. The binding throws on failure with `.code` and
  `.message`, so no `response.ok` check is needed — the throw is already the retry
  signal the kit wants.
- **Always send `text` as well as `html`.** Some clients show only plain text, and a
  missing text part hurts spam scoring.
- **Reply-to is not the enquirer.** If you set `replyTo` from a submitted email
  address you are letting an unauthenticated form set a header. Put the address in
  the body, as above, and let the reader copy it.
- **This is transactional email only.** Do not route marketing sends through it.

`destination_address` is per-binding, so a second recipient is a second binding
rather than a second `to`. Declaring it in only one wrangler block is the usual
mistake — named environments do not inherit.

## Choosing

| Channel | Good for | Watch |
| --- | --- | --- |
| `logNotifier` | development, and any site with no real destination yet | nobody is told anything |
| Slack | a team that already lives there | webhook URL is a secret |
| Email | a durable record, long message bodies, non-technical readers | domain onboarding, deliverability |
| Telegram | a solo operator who wants a phone buzz | 4096-character cap |
| SMS | genuine urgency | costs money per segment; truncate hard |
| `queueNotifier` | handing off to a middle stage | not a person |

A fallback notifier should not be the channel that just failed. If Slack is the
primary, make email or Telegram the `resolveFallback` — otherwise the outage that
caused the fallback also swallows it. Using the same channel for both is only
reasonable when the likely failure is a transient 5xx rather than an outage.
