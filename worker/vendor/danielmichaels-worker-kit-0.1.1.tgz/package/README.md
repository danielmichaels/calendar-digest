# worker-kit

Form ingress and notification egress for Cloudflare Workers, plus Cloudflare Access for
the operator pages a Worker serves itself.

The kit owns the parts every marketing-site form Worker needs and none of the parts
that differ between sites. It routes and guards the request, persists the payload
and a delivery row in one atomic batch, publishes an envelope, consumes it, and
sweeps anything the queue dropped. The site supplies its own field schema, its own
SQL and its own notification wording.

Standing up a new site is a `wrangler.jsonc`, a field schema and notification
wording. No kit function takes a table name.

## Install

```sh
pnpm add @danielmichaels/worker-kit hono
```

`hono` is an optional peer dependency, needed only for the route helpers and
`createWorker`.

The package has no root export. Import from the subpath you need:

| Subpath | Holds |
| --- | --- |
| `/worker` | `createWorker` |
| `/hono` | `submitRoute`, `originGuard`, `turnstileGuard`, `rateLimitGuard`, `submissionReader` |
| `/access` | `authenticateAccess`, `isReservedPath`, `issueCsrfToken`, `verifyCsrfToken`, `readForm`, `operatorHeaders`, `parseEmailList` |
| `/notify` | `logNotifier`, `slackNotifier`, `postSlackMessage`, `queueNotifier`, `Notification`, `Notifier` |
| `/queue`, `/sweep` | `queueHandler`, `sweepHandler` for wiring without `createWorker` |
| `/errors` | `KitErrorCode`, `FieldErrors`, `errorResponse` |
| `/envelope` | `DeliveryEnvelope`, `deliveryEnvelope`, `ENVELOPE_VERSION` |
| `/store`, `/delivery` | the `deliveries` reader and its insert statement |
| `/migrations` | `KIT_MIGRATIONS`, used by the CLI |
| `/testing` | `fakeQueue`, `recordingNotifier` |
| `/turnstile`, `/cors`, `/submission`, `/http`, `/publish`, `/bindings` | the pieces underneath |

## Releasing

Bump `version` in `package.json`, merge, then push a matching tag (`git tag v0.1.0 &&
git push origin v0.1.0`). `.github/workflows/publish.yml` reruns typecheck, tests, build and
the pack fixture, then publishes to npm with the `NPM_TOKEN` repository secret (a granular
npm token allowed to publish `@danielmichaels/worker-kit`). A tag that does not match the
version fails before publishing.

## Quick start

```sh
npx worker-kit init my-site
npx worker-kit sync-migrations
```

`init` prints the `wrangler.jsonc` blocks to paste in. Named environments do not
inherit, so every binding, var, queue and trigger appears twice on purpose — a
missing staging cron fails silently. `sync-migrations` writes the kit's migrations
into your `migrations/` directory.

```ts
import { submitRoute } from '@danielmichaels/worker-kit/hono';
import { createWorker } from '@danielmichaels/worker-kit/worker';
import { slackNotifier } from '@danielmichaels/worker-kit/notify';

export default createWorker<'contact', AppEnv>({
	routes: {
		'POST /api/contact': submitRoute<'contact', EnquiryInput>({
			kind: 'contact',
			sourceTable: 'enquiries',
			validate: validateEnquiry,
			toStatements: enquiryStatements,
			summarize: summarizeEnquiry,
		}),
	},
	resolveNotifiers: (_kind, env) => [slackNotifier({ url: env.SLACK_WEBHOOK_URL })],
});
```

`createWorker` returns a Worker with `fetch`, `queue` and `scheduled`, and installs
`originGuard` across every route. Route keys read `"METHOD /path"`.

## What to bind

| Binding | Kind | Purpose |
| --- | --- | --- |
| `DB` | D1 | payload tables and `deliveries` |
| `NOTIFY_QUEUE` | Queue | producer *and* consumer, same queue |
| `SUBMIT_LIMITER` | Rate limit | keyed on `CF-Connecting-IP` |
| `ALLOWED_ORIGINS` | var | comma-separated origin allow list |
| `TURNSTILE_SECRET_KEY` | secret | `wrangler secret put`, never a var |
| `TURNSTILE_DISABLED` | var, optional | `"true"` skips Turnstile for localhost origins only |

The names are fixed. If a site must differ, pass `db` and `queue` accessors to
`createWorker`.

`ALLOWED_ORIGINS` entries may contain one `*`, which matches exactly one label —
no dots and no slashes. `https://site-*-scope.vercel.app` matches a Vercel preview
branch but not `https://evil-site-x-scope.vercel.app`, and not a nested subdomain.

## What to implement

Four functions per form, all pure except `toStatements`:

```ts
validate:     (fields: Record<string, string>) => ValidationResult<V>
toStatements: (value: V, ctx: SubmitContext) => D1PreparedStatement[]
summarize:    (value: V) => DeliverySummary
resolveNotifiers: (kind: K, env: E) => Notifier[]
```

`validate` returns `{ ok: true, value }` or `{ ok: false, errors }`, where `errors`
is a `{ field: message }` map. Report every invalid field at once; the browser shows
them all.

`toStatements` writes your SQL. It receives `{ db, id, request }` — `request` is
there so you can store the client IP or User-Agent, which nothing else in the seam
can reach. The kit appends its own `deliveries` insert and runs the lot through
`db.batch()`, so the payload row and the delivery row land together or not at all.

`summarize` produces the one-line `summary` and the `fields` snapshot stored on the
delivery and handed to every notifier. Omit a field to keep it out of the
notification.

`resolveNotifiers` maps a `kind` to the notifiers that should receive it. Returning
an empty array marks the delivery `unroutable` rather than silently dropping it.

## Responses

| Condition | Status | Body |
| --- | --- | --- |
| Accepted, client asked for JSON | `201` | `{"ok":true}` |
| Accepted, browser form post | `303` | `Location: <origin><returnPath>?submitted=1` |
| Malformed body | `400` | `{"ok":false,"error":"bad_request"}` |
| Failed validation | `400` | `{"ok":false,"error":"validation","errors":{…}}` |
| Origin not allowed | `403` | `{"ok":false,"error":"origin"}` |
| Turnstile rejected | `403` | `{"ok":false,"error":"turnstile"}` |
| Rate limited | `429` | `{"ok":false,"error":"rate_limited"}` |
| Persist failed | `500` | `{"ok":false,"error":"internal"}` |

`error` is a stable machine code, never display text. `errors` appears only on
`validation` and carries your own wording. A frontend should render `errors` per
field and map `error` to its own sentence for everything else.

A form post is answered with a `303` unless the client sends
`Accept: application/json`. Send that header from `fetch` or you will follow a
redirect you did not want. The redirect target comes from a `returnPath` field,
rejected unless it is same-origin and not protocol-relative.

Two fields are read but never stored: `cf-turnstile-response` carries the token,
and `website` is the honeypot — fill it and the request is answered `201` while
nothing is written. Override the honeypot name with `honeypot`.

Turnstile verification checks the token's `action` against the route's `kind` by
default. **Your widget must send a matching `data-action`** or every submission is
rejected. Override with `action`, or pass `action: ''` to disable the check.
A token minted with a Turnstile *testing* key skips the action check, so a staging
environment using a testing sitekey cannot catch a missing `data-action`.

## The wire envelope

What the queue carries. Language-neutral, so a middle stage in any runtime can read
and republish it:

```json
{
  "v": 1,
  "id": "0b7c…",
  "kind": "contact",
  "type": "delivery.pending",
  "occurredAt": "2026-09-07T10:06:04.612Z",
  "source": { "table": "enquiries", "id": "0b7c…" }
}
```

`id` is the `deliveries` primary key. `source` points at the payload row, which may
differ from `id` if you set `sourceId`. The envelope carries no payload: D1 is the
source of truth and the consumer re-reads the row, so a publish failure is
recoverable and never fails the request.

`v` rules:

- A consumer **must** retry an envelope whose `v` it does not recognise, never ack
  it. A rolling deploy will hand old consumers new envelopes; retrying lets the
  message survive until the new code is live.
- Additive fields do not bump `v`. Removing or repurposing a field does.
- `type` distinguishes stages on the same version. `delivery.pending` is what
  `submitRoute` publishes and what `queueHandler` expects; a middle stage publishes
  something else, and the terminal consumer is configured with `expectType`.

## Delivery lifecycle

`status` moves `new` → `notified`, or to `failed`/`unroutable` once the sweep gives
up. `sweeps` counts cron passes, not queue retries.

The queue consumer sends every channel that has not already delivered, all at once,
and acks when they have all resolved. A channel's success is recorded the moment it
lands, so a retry re-sends only the channels that failed — a Slack outage cannot
block email, and a retry cannot duplicate the Slack post. If every channel throws
it records `last_error` and retries the message. If `resolveNotifiers` returns
nothing the row is marked `unroutable`.

The cron sweep republishes deliveries still `new` or `unroutable` after
`staleAfterMs` (default 5 minutes, limit 50 per pass). After `maxSweeps` (default 5)
it stops republishing, sends the submission through the fallback notifiers that
have not already delivered, with a `meta` block describing why, stamps `fallback_at`
and marks the row terminal. A row that already has `fallback_at` is skipped, so no
delivery produces more than one fallback.

`staleAfterMs` must exceed the queue's total retry window
(`max_retries × retry_delay`) or the sweep will republish a message that is still
retrying and you will get a duplicate notification. With the default `retry_delay`
of 0 the window is short and 5 minutes is comfortable.

**There is no dead letter queue anywhere in this design, and you should not
configure one.** A DLQ only holds messages that reached the queue; the gap being
covered is a D1 write that succeeded followed by a publish that did not. Two
recovery paths racing is what the sweep replaced.

## Migrations

The kit owns migration `9000_worker_kit_deliveries.sql`, which creates `deliveries`
and its partial index. Version numbers from **9000 up are reserved for the kit** —
number your own below that. `worker-kit sync-migrations` writes any missing kit
migration into your directory; it never edits one you already have.

Deliveries store `created_ms` as an INTEGER epoch, not a text timestamp, so the
sweep does no string comparison.

## Notifiers

A notifier is a name and one method:

```ts
interface Notifier {
	name: string;
	send(notification: Notification): Promise<void>;
}
```

`name` is the channel's identity, recorded on the delivery when it succeeds. It
must be stable across deploys and unique within the array `resolveNotifiers`
returns — two Slack webhooks are `name: 'slack-ops'` and `name: 'slack-sales'`,
never two `'slack'`s.

It receives `{ id, kind, summary, fields, source, meta? }`. `meta` is present only
on the fallback path and carries `{ status, attempts, lastError }`.

Two rules. **Throw to retry** — resolving means delivered, and that channel is
recorded so no later attempt repeats it. And **tolerate duplicates**: Queues are
at-least-once, and a sweep can race a retry.

Three ship with the kit:

| Notifier | Use |
| --- | --- |
| `logNotifier` | a const, not a factory. Writes to Workers logs. |
| `slackNotifier({ url, format, name })` | `format` defaults to `defaultSlackFormat`; pass your own to keep a site's wording. |
| `queueNotifier(queue, { type, name })` | hands the envelope to the next stage instead of a person. |

`postSlackMessage(url, text)` is the same webhook call for a message that is not a
delivery, such as a reminder from a cron. Both time out after ten seconds and treat a
redirect as a failure.

Telegram, SMS and email are a dozen lines each and live in your own repo, because a
new channel should never need a kit release. Worked implementations are in
**[docs/notifiers.md](docs/notifiers.md)**.

## Operator pages behind Cloudflare Access

`/access` is for a Worker that serves its own admin pages (an incident console, a link
manager). It has no dependencies and does not need Hono. Cloudflare Access in front of the
route is necessary but not sufficient, because a request can arrive by another hostname, by
a path spelling the Access rule misses, or with a forged identity header. So the Worker
checks for itself:

```ts
import {
	authenticateAccess,
	isReservedPath,
	issueCsrfToken,
	operatorHeaders,
	parseEmailList,
	readForm,
	verifyCsrfToken,
} from '@danielmichaels/worker-kit/access';

const access = (env: Env) => ({
	host: env.ADMIN_HOST,
	teamDomain: env.ACCESS_TEAM_DOMAIN,
	audience: env.ACCESS_AUD,
	allow: { emails: parseEmailList(env.ADMIN_EMAILS) },
});

if (isReservedPath(url.pathname, '/admin')) {
	const operator = await authenticateAccess(request, access(env));
	if (!operator) return new Response('Access denied', { status: 403, headers: operatorHeaders() });
	// GET: render forms with issueCsrfToken(operator.email, env.ADMIN_CSRF_SECRET)
	// POST: readForm(request), then verifyCsrfToken(request, operator.email, secret, form.get('csrf'))
}
```

- `authenticateAccess` returns `{ email }` (lower-cased) or `null`. It verifies the
  `Cf-Access-Jwt-Assertion` RS256 signature against the team's keys (cached five minutes,
  refetched once for an unknown `kid`, retried no sooner than 30 seconds after a failure),
  the exact issuer, the audience, `exp`/`iat`/`nbf`, the canonical HTTPS host with no
  port, and the allow rule. Unsigned identity headers are never read.
- `allow` is explicit: `{ emails }` for a named list, or `{ domain }` for exactly one email
  domain (not subdomains). Membership of the Workspace is not a permission by default.
- Missing or malformed config (host, team domain, audience, an empty allow rule) is a
  refusal, never an open door. So is an unset CSRF secret: `issueCsrfToken` throws.
- `isReservedPath` matches the prefix in any case, with repeated slashes or percent-encoded,
  and decodes escapes byte by byte so a malformed escape cannot hide it. Send every match through `authenticateAccess`
  and 404 unknown paths only after authenticating.
- CSRF tokens are HMAC-signed, bound to the operator's email, live 30 minutes, and verify
  only on a POST whose `Origin` is exactly the request's own HTTPS origin.
- `readForm` accepts only `application/x-www-form-urlencoded`, caps the body (16 KiB by
  default) and rejects repeated fields.
- `operatorHeaders()` is `no-store`, `DENY` framing, and a CSP with `form-action 'self'`;
  pass `{ style, script, img, font }` for what the page loads.

The Access application itself (hostnames, paths, policy) is configured in Cloudflare, not
here. Cover both `/admin` and `/admin/*`, and keep the Worker's allow rule in step with the
Access policy: the Worker's check is what holds if the two ever disagree.

## Middle stages

The kit supports a chain of Workers between ingress and egress without knowing they
exist. A middle stage:

- consumes an envelope and publishes an envelope, changing `type`, never `v`
- **never writes `deliveries`** — only the first and last stage touch that table
- configures **no** dead letter queue
- is idempotent in its own storage, because the whole chain replays on a stall

There is deliberately no `stage` column. Queues are at-least-once, so every middle
stage must be idempotent regardless; a column would buy one queue hop while forcing
every middle worker to hold a D1 binding and know the schema. The cost is that a
stall replays the chain from the beginning, which is correct while stages are cheap.
If one ever becomes expensive, adding `stage` is `ALTER TABLE ADD COLUMN` plus a
sweep change — the envelope's `v` field is what keeps that non-breaking.

A middle worker that never completes leaves its row swept to `failed` and surfaced
through the fallback, with the kit unaware that worker exists.

## Without createWorker

`createWorker` is a thin wrapper. Ingress and egress can deploy as separate Workers
reading and writing different queue bindings:

```ts
import { queueHandler } from '@danielmichaels/worker-kit/queue';
import { sweepHandler } from '@danielmichaels/worker-kit/sweep';

export default {
	queue: queueHandler({ resolveNotifiers }),
	scheduled: sweepHandler({ resolveFallback, sweep: { staleAfterMs: 600_000 } }),
};
```

`submitRoute` returns a tuple of Hono handlers that mounts into an app typed on
your own `Env`. The guards are individually exported if you want a different order.

## Testing

`@danielmichaels/worker-kit/testing` provides `fakeQueue` (records what was
published, or throws on demand) and `recordingNotifier`. Drive the real Worker
under `@cloudflare/vitest-pool-workers` against a real D1 rather than unit-testing
the pieces the kit already covers.
